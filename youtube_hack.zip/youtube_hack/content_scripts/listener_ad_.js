var player,h,m,s,d,id_chk,observer;

var ua = detect.parse(navigator.userAgent);

const callback = function(mutationsList, observer) {
       var i;
       for (let mutation of mutationsList) {           
           if (mutation.type === 'childList') {
               var add_nodes = mutation.addedNodes;               
               if (add_nodes.length)
               {
                   if (add_nodes[0].nodeType==1)
                   {
                       if (add_nodes[0].classList.contains('ytp-ad-player-overlay'))
                       {
                          d = new Date();
                          console.log ('ytp-ad-player-overlay -- реклама ',addZero(d.getHours()),':',addZero(d.getMinutes()),':',addZero(d.getSeconds()));
                          var preskip = document.querySelectorAll("[id^='preskip-component']");
                          if (preskip.length)
                          {
                              d = new Date();
                              console.log ('обнаружен preview - component class="',preskip[0].classList.value,'"',addZero(d.getHours()),':',addZero(d.getMinutes()),':',addZero(d.getSeconds()));
                               try {
                                    while (preskip[0].firstChild) {                       
                                      preskip[0].removeChild(preskip[0].firstChild);
                                    }
                              //      preskip[0].parentElement.removeChild (preskip[0]);
                                    preskip[0].style.display = 'none';
                                    console.log ('preview - component успешно удален');
                                } catch (ex) {
                                    console.error('Ошибка при удалении preview - component ->', ex.message);
                                }    
                          }
                          var skip = document.querySelectorAll('.ytp-ad-skip-button-slot');
                          if (skip.length)
                          {
                              if (skip[0].style.display=='none')
                                  skip[0].style.display= 'block';
                              search_skip (skip[0]);
                          }else
                          {
                              var preview = document.querySelectorAll(".ytp-ad-preview-slot");
                              if (preview.length)
                              {
                                  d = new Date();
                                  console.log ('принудительный рекламный ролик preview ',addZero(d.getHours()),':',addZero(d.getMinutes()),':',addZero(d.getSeconds()));  
                                  console.log ('Перезапускаю страницу ...');
                                  try {
                                        
                                        document.location.reload();
                                        
                                  }catch (ex) {
                                        console.log ('Ошибка перезапуска страницы ->',ex.message);
                                  }
                                    
                              }                             
                          }                        
                       }
                       if (add_nodes[0].classList.contains('ytp-ad-overlay-slot'))
                       {
                          d = new Date();
                          console.log ('всплывающий рекламный баннер ',addZero(d.getHours()),':',addZero(d.getMinutes()),':',addZero(d.getSeconds()));

                          try {
                              while (add_nodes[0].firstChild) {                       
                                add_nodes[0].removeChild(add_nodes[0].firstChild);
                              }
                              add_nodes[0].style.display = 'none';
                              console.log ('рекламный баннер успешно удален');
                          }
                          catch (ex) {
                              console.error('Ошибка при удалении баннера ->', ex.message);
                          }                          
                          
                       }
                   }  
               }
           }                                              
       }
    };

const config = {
  childList: true,
  subtree: true,
  characterData: true
};    

var state_serv  = {
  running: true,
  error: false
};

function search_skip (node)
{
  for (var i = 0; i < node.children.length; i++) {        
    if (node.children[i].style.display == 'none')
    {
        if (node.children[i].tagName.toLowerCase()=='span')
            node.children[i].style.display = 'inline-block';
        else
            node.children[i].style.display = 'block';

    }
    
    if (node.children[i].textContent.toLowerCase()=='пропустить рекламу'||
        node.children[i].textContent.toLowerCase()=='пропустить')
    {
       d = new Date();
       console.log ('инициирую пропуск рекламы',addZero(d.getHours()),':',addZero(d.getMinutes()),':',addZero(d.getSeconds()));
       try {
            var but_skip = node.children[i].parentElement;
            var event = new MouseEvent('click', {
                'view': window,
                'bubbles': true,
                'cancelable': true
            });
            but_skip.dispatchEvent( event );
            return;

       } catch (ex) {
            console.error('Ошибка инициации пропуска рекламы->', ex.message);
            return;
       }
       
    }
    search_skip (node.children[i]);
  }
}

function Listener_msg(request, sender, sendResponse) {
  
  d = new Date();
  h = addZero(d.getHours());
  m = addZero(d.getMinutes());
  s = addZero(d.getSeconds());
  if (request.runServer=='Остановить')
  {    
      observer.disconnect();     
      console.log ('stop ad-blocker -- ',h,':',m,':',s);
      state_serv.running = false;
  }else if (request.runServer=='Запустить')
  {
      observer.observe(player, config);
      console.log ('start ad-blocker -- ',h,':',m,':',s);
      state_serv.running = true;
  }
  if (ua.browser.family=='Chrome')
      chrome.runtime.sendMessage(state_serv,null);
  else
      browser.runtime.sendMessage(state_serv,null);
  
}

function addZero(i) {
  if (i < 10) {
    i = "0" + i;
  }
  return i;
}
(ua.browser.family=='Chrome')?
chrome.tabs.onActivated.addListener(handleActivated):
browser.tabs.onActivated.addListener(handleActivated);

function start () {
  player = document.getElementById('movie_player');
  if (!player)
  {
      d = new Date();

      h = addZero(d.getHours());
      m = addZero(d.getMinutes());
      s = addZero(d.getSeconds());
      console.log ('Плеер не найден. Попытка проверки через каждые 1 сек',addZero(d.getHours()),':',addZero(d.getMinutes()),':',addZero(d.getSeconds()));
      id_chk = setInterval (check_player,1000);
  } else
      start_server ();
}


function start_server () {
    try {
      observer = new MutationObserver(callback);
      d = new Date();

      h = addZero(d.getHours());
      m = addZero(d.getMinutes());
      s = addZero(d.getSeconds());
      observer.observe(player, config);
      console.log ('start ad-blocker -- ',h,':',m,':',s);

      try {
            if (ua.browser.family=='Chrome') 
                chrome.runtime.onMessage.addListener(Listener_msg);
            else
                browser.runtime.onMessage.addListener(Listener_msg);
      }catch (ex) {
            console.error('Ошибка подключения слушателя ->', ex.message);
            state_serv.error = true;
      }
      
    }catch (ex)
    {
          console.error('Ошибка при запуске сервера  ->', ex.message);
          state_serv.error = true;
    }

}

function check_player () {
    player = document.getElementById('movie_player');
    if (player)
    {
        clearInterval (id_chk);
        d = new Date();

        h = addZero(d.getHours());
        m = addZero(d.getMinutes());
        s = addZero(d.getSeconds());
        console.log ('Плееер обнаружен ',h,':',m,':',s);
        start_server ();
    }
}





    